package com.kttt.moremod.world.dimension;

import com.kttt.moremod.MoreMod;
import net.minecraft.registry.Registerable;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.intprovider.UniformIntProvider;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionOptions;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.dimension.DimensionTypes;

import java.util.OptionalLong;

public class ModDimensions {
    public static final RegistryKey<DimensionOptions> BUILD_KEY = RegistryKey.of(RegistryKeys.DIMENSION,
            Identifier.of(MoreMod.MOD_ID, "build"));
    public static final RegistryKey<World> BUILD_LEVEL_KEY = RegistryKey.of(RegistryKeys.WORLD,
            Identifier.of(MoreMod.MOD_ID, "build"));
    public static final RegistryKey<DimensionType> BUILD_DIMENSION_TYPE_KEY = RegistryKey.of(RegistryKeys.DIMENSION_TYPE,
            Identifier.of(MoreMod.MOD_ID, "build_type"));

    public static void bootstrap(Registerable<DimensionType> context) {
        context.register(BUILD_DIMENSION_TYPE_KEY, new DimensionType(
                OptionalLong.of(12000), //一天时间
                false, //天空光
                false, //天花板
                false, //极热
                true, //自然维度
                1.0, //缩放
                true, //床工作
                false, //重生锚工作
                0, //min(Y)
                256, //维度高度
                256, //逻辑高度
                BlockTags.INFINIBURN_OVERWORLD, //燃烧快
                DimensionTypes.OVERWORLD_ID, //环境效果
                1.0f, //环境光
                new DimensionType.MonsterSettings(false, false, UniformIntProvider.create(0,0), 0)
        ));
    }
}
